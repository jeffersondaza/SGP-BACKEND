export enum RolesEnum{
    Admin = "ADMINISTRADOR",
    Student = "ESTUDIANTE",
    Teacher = "PROFESOR"
}