export interface RespondInterface {
  status: string;
  msg: string;
  data: any;
}
