export interface ParticipantModelInterface {
  usuario: string;
  proyecto: number;
  fecha_inicio: Date;
  fecha_fin: Date;
  rol: string;
}
