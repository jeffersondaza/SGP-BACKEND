export interface ProgramModelInterface {
    id: number;
    nombre: string;
    facultad_id: number;
    director: string;
  }