export interface ReportModelInterface {
  usuario: string;
  file: File;
}
