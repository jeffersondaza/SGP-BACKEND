export interface RoleModelInterface {
  id: number;
  tipo_usuario: string;
  USUARIOS: string;
  PROGRAMAS: string;
  FACULTADES: string;
  EVENTOS: string;
  PROYECTOS: string;
  SEMILLEROS: string;
  REPORTES: string;
  ROLES: string;
}
