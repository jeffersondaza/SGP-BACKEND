
export const endpoints = {
    uploadFile: '/archivo/upload'
}