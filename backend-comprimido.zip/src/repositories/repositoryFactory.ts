import sgpRepository from "./sgpRepository";

export const RepositoryFactory = {
    RepositorySGP: sgpRepository
} 